import { NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

const PUBLIC_PATHS = [
  '/api/auth/login',
  '/api/configuracion/logo',
  '/login',
];

function getSecretKey() {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET no definido');
  return new TextEncoder().encode(secret);
}

export async function middleware(request) {
  const { pathname } = request.nextUrl;

  // Permitir rutas públicas
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Proteger todas las rutas /api/* y páginas internas
  if (pathname.startsWith('/api/') || pathname.startsWith('/dashboard') ||
      pathname.startsWith('/clientes') || pathname.startsWith('/prestamos') ||
      pathname.startsWith('/cobros') || pathname.startsWith('/usuarios') ||
      pathname.startsWith('/reportes') || pathname.startsWith('/auditoria') ||
      pathname.startsWith('/configuracion') || pathname.startsWith('/recordatorios') ||
      pathname.startsWith('/recibo')) {

    const token = request.cookies.get('auth_token')?.value;

    if (!token) {
      if (pathname.startsWith('/api/')) {
        return NextResponse.json({ error: 'No autorizado.' }, { status: 401 });
      }
      return NextResponse.redirect(new URL('/login', request.url));
    }

    try {
      await jwtVerify(token, getSecretKey());
      return NextResponse.next();
    } catch {
      if (pathname.startsWith('/api/')) {
        return NextResponse.json({ error: 'Sesión inválida o expirada.' }, { status: 401 });
      }
      const response = NextResponse.redirect(new URL('/login', request.url));
      response.cookies.delete('auth_token');
      return response;
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|apple-icon.png).*)'],
};
