import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAdmin } from '@/lib/auth';
import bcrypt from 'bcryptjs';

export async function PUT(request, { params }) {
  const { errorResponse } = await requireAdmin(request);
  if (errorResponse) return errorResponse;

  try {
    const { id } = await params;
    const body = await request.json();
    const { nombre, rol, password, permisos } = body;

    if (!nombre || !rol) {
      return NextResponse.json({ error: 'Nombre y rol son obligatorios' }, { status: 400 });
    }

    const ROLES_VALIDOS = ['admin', 'cobrador', 'supervisor'];
    if (!ROLES_VALIDOS.includes(rol)) {
      return NextResponse.json({ error: 'Rol inválido.' }, { status: 400 });
    }

    const userPermisos = Array.isArray(permisos) ? permisos : [];

    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10);
      await query('UPDATE usuarios SET nombre=$1, rol=$2, password_hash=$3, permisos=$4 WHERE id=$5',
        [nombre, rol, hashedPassword, JSON.stringify(userPermisos), id]);
    } else {
      await query('UPDATE usuarios SET nombre=$1, rol=$2, permisos=$3 WHERE id=$4',
        [nombre, rol, JSON.stringify(userPermisos), id]);
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: 'Error al actualizar usuario' }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  const { user, errorResponse } = await requireAdmin(request);
  if (errorResponse) return errorResponse;

  try {
    const { id } = await params;

    // No permitir que un admin se elimine a sí mismo
    if (String(user.id) === String(id)) {
      return NextResponse.json({ error: 'No puedes eliminar tu propia cuenta.' }, { status: 400 });
    }

    await query('DELETE FROM usuarios WHERE id = $1', [id]);
    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: 'Error al eliminar usuario' }, { status: 500 });
  }
}
