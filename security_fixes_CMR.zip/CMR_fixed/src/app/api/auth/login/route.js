import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { getClientIp, getSecretKey } from '@/lib/auth';
import bcrypt from 'bcryptjs';
import { SignJWT } from 'jose';

// Rate limiting simple en memoria (para producción usar Redis/Upstash)
const loginAttempts = new Map();
const MAX_ATTEMPTS = 5;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutos

function checkRateLimit(ip) {
  const now = Date.now();
  const record = loginAttempts.get(ip);

  if (!record || now - record.firstAttempt > WINDOW_MS) {
    loginAttempts.set(ip, { count: 1, firstAttempt: now });
    return { allowed: true, remaining: MAX_ATTEMPTS - 1 };
  }

  if (record.count >= MAX_ATTEMPTS) {
    const retryAfter = Math.ceil((record.firstAttempt + WINDOW_MS - now) / 1000);
    return { allowed: false, retryAfter };
  }

  record.count++;
  return { allowed: true, remaining: MAX_ATTEMPTS - record.count };
}

function clearRateLimit(ip) {
  loginAttempts.delete(ip);
}

export async function POST(request) {
  const ip = getClientIp(request);
  const rateLimit = checkRateLimit(ip);

  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Demasiados intentos fallidos. Intente de nuevo en ${rateLimit.retryAfter} segundos.` },
      { status: 429 }
    );
  }

  try {
    const body = await request.json();
    const { username, password } = body;

    if (!username || !password) {
      return NextResponse.json({ error: 'Faltan credenciales.' }, { status: 400 });
    }

    const res = await query('SELECT * FROM usuarios WHERE username = $1', [username]);
    if (res.rows.length === 0) {
      return NextResponse.json({ error: 'Credenciales inválidas.' }, { status: 401 });
    }

    const user = res.rows[0];
    const passwordMatch = await bcrypt.compare(password, user.password_hash);

    if (!passwordMatch) {
      return NextResponse.json({ error: 'Credenciales inválidas.' }, { status: 401 });
    }

    // Login exitoso: limpiar intentos fallidos
    clearRateLimit(ip);

    const token = await new SignJWT({
      id: user.id,
      username: user.username,
      rol: user.rol,
      nombre: user.nombre,
    })
      .setProtectedHeader({ alg: 'HS256' })
      .setExpirationTime('8h')
      .setIssuedAt()
      .sign(getSecretKey());

    const response = NextResponse.json({
      success: true,
      user: { id: user.id, username: user.username, rol: user.rol, nombre: user.nombre },
    });

    response.cookies.set({
      name: 'auth_token',
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 60 * 60 * 8, // 8 horas
    });

    return response;
  } catch (err) {
    console.error('Login API error:', err);
    return NextResponse.json({ error: 'Error en el servidor al iniciar sesión.' }, { status: 500 });
  }
}
