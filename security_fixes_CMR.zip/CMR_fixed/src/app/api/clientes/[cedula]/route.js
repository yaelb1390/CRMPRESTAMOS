import { NextResponse } from 'next/server';
import { query } from '@/lib/db';
import { requireAuth, requireAdmin } from '@/lib/auth';

export async function GET(request, { params }) {
  const { errorResponse } = await requireAuth(request);
  if (errorResponse) return errorResponse;

  try {
    const { cedula } = await params;
    const clientRes = await query(`
      SELECT id, cedula, nombre, telefono, telefono2, direccion, fecha_ingreso,
        score_crediticio, clasificacion, total_prestamos, prestamos_liquidados,
        capital_prestado, capital_pagado, intereses_pagados,
        cuotas_puntuales, cuotas_tardias, max_dias_atraso, promedio_dias_atraso,
        metodo_desembolso, banco_nombre, numero_cuenta, email, created_at
      FROM clientes WHERE cedula = $1
    `, [cedula]);

    if (clientRes.rows.length === 0) {
      return NextResponse.json({ error: 'No se encontró ningún cliente con esa cédula.' }, { status: 404 });
    }

    const loansRes = await query(`
      SELECT numero_prestamo, monto_aprobado, balance_pendiente, cuota_mensual,
        fecha_proximo_pago, estado, dias_atraso, tipo_frecuencia, total_cuotas, cuotas_pagadas, created_at
      FROM prestamos WHERE cedula = $1 ORDER BY created_at DESC
    `, [cedula]);

    return NextResponse.json({
      data: {
        ...clientRes.rows[0],
        prestamos: loansRes.rows.map(row => ({
          ...row,
          monto_aprobado: parseFloat(row.monto_aprobado),
          balance_pendiente: parseFloat(row.balance_pendiente),
          cuota_mensual: parseFloat(row.cuota_mensual),
        })),
      },
    });
  } catch (err) {
    console.error('Client GET Detail API error:', err);
    return NextResponse.json({ error: 'Error de base de datos al obtener el detalle del cliente.' }, { status: 500 });
  }
}

export async function PUT(request, { params }) {
  const { user, errorResponse } = await requireAuth(request);
  if (errorResponse) return errorResponse;

  try {
    const { cedula } = await params;
    const body = await request.json();
    const { nombre, telefono, telefono2, direccion, metodo_desembolso, banco_nombre, numero_cuenta, email } = body;

    const checkRes = await query('SELECT * FROM clientes WHERE cedula = $1', [cedula]);
    if (checkRes.rows.length === 0) {
      return NextResponse.json({ error: 'No se encontró ningún cliente con esta cédula.' }, { status: 404 });
    }

    if (!nombre || nombre.trim().length < 3 || nombre.trim().length > 100) {
      return NextResponse.json({ error: 'El nombre completo debe tener entre 3 y 100 caracteres.' }, { status: 400 });
    }

    const oldData = checkRes.rows[0];
    await query(`
      UPDATE clientes SET nombre=$1, telefono=$2, telefono2=$3, direccion=$4,
        metodo_desembolso=$5, banco_nombre=$6, numero_cuenta=$7, email=$8, updated_at=CURRENT_TIMESTAMP
      WHERE cedula=$9
    `, [nombre.trim(), telefono || null, telefono2 || null, direccion || null,
        metodo_desembolso || 'efectivo', banco_nombre || null, numero_cuenta || null, email || null, cedula]);

    try {
      const { registrarAuditoria } = await import('@/lib/audit');
      await registrarAuditoria({ tabla: 'clientes', accion: 'UPDATE', registro_id: cedula,
        datos_anteriores: { nombre: oldData.nombre, telefono: oldData.telefono, direccion: oldData.direccion },
        datos_nuevos: { nombre: nombre.trim(), telefono, telefono2, direccion }, usuario: user });
    } catch (e) { console.error('Error en auditoría:', e); }

    return NextResponse.json({ success: true, message: 'Datos del cliente actualizados correctamente', data: { cedula, nombre } });
  } catch (err) {
    console.error('Client PUT API error:', err);
    return NextResponse.json({ error: 'Error de base de datos al actualizar el cliente.' }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  const { errorResponse } = await requireAdmin(request);
  if (errorResponse) return errorResponse;

  try {
    const { cedula } = await params;
    const { user } = await requireAdmin(request);

    const checkRes = await query('SELECT * FROM clientes WHERE cedula = $1', [cedula]);
    if (checkRes.rows.length === 0) {
      return NextResponse.json({ error: 'No se encontró ningún cliente con esta cédula.' }, { status: 404 });
    }

    const loansRes = await query("SELECT id FROM prestamos WHERE cedula = $1 AND estado != 'pagado'", [cedula]);
    if (loansRes.rows.length > 0) {
      return NextResponse.json({ error: 'No se puede eliminar un cliente con préstamos activos.' }, { status: 400 });
    }

    const oldData = checkRes.rows[0];
    await query('DELETE FROM clientes WHERE cedula = $1', [cedula]);

    try {
      const { registrarAuditoria } = await import('@/lib/audit');
      await registrarAuditoria({ tabla: 'clientes', accion: 'DELETE', registro_id: cedula,
        datos_anteriores: oldData, usuario: user });
    } catch (e) { console.error('Error en auditoría:', e); }

    return NextResponse.json({ success: true, message: 'Cliente eliminado correctamente' });
  } catch (err) {
    console.error('Client DELETE API error:', err);
    return NextResponse.json({ error: 'Error de base de datos al eliminar el cliente.' }, { status: 500 });
  }
}
